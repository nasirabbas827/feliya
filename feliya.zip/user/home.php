<?php
include('config.php');

session_start();

// Check if user is logged in, if not, redirect to login page
if (!isset($_SESSION["id"]) || empty($_SESSION["id"])) {
    header("location: index.php");
    exit;
}

// Get the user ID from the session
$user_id = $_SESSION["id"];

// Fetch user balance from the database
$sql_balance = "SELECT balance FROM users WHERE id = ?";
$stmt_balance = mysqli_prepare($conn, $sql_balance);
mysqli_stmt_bind_param($stmt_balance, "i", $user_id);
mysqli_stmt_execute($stmt_balance);
mysqli_stmt_bind_result($stmt_balance, $balance);
mysqli_stmt_fetch($stmt_balance);
mysqli_stmt_close($stmt_balance);

// Fetch all packages from the database
$sql = "SELECT p.*, s.subscription_id, s.status AS subscription_status
        FROM packages p
        LEFT JOIN subscriptions s ON p.package_id = s.package_id AND s.user_id = ?
        ORDER BY p.package_id ASC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
<?php include('navbar.php'); ?>

<div class="container mt-5">
    <div class="mt-3">
        <h5>Your Balance: $<?php echo $balance; ?></h5>
    </div>
    <h2 class="mb-4">Available Packages</h2>
    <div class="row">
        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $row['title']; ?></h5>
                        <p class="card-text"><?php echo $row['description']; ?></p>
                        <p class="card-text">Amount: $<?php echo $row['amount']; ?></p>
                        <p class="card-text">Daily Profit: <?php echo $row['daily_profit']; ?>$</p>
                        <?php if ($row['subscription_id'] && $row['subscription_status'] === 'completed') : ?>
                            <a href="subscription_details.php?subscription_id=<?php echo $row['subscription_id']; ?>" class="btn btn-primary">View Details</a>
                        <?php elseif (!$row['subscription_id']) : ?>
                            <a href="subscribe.php?package_id=<?php echo $row['package_id']; ?>" class="btn btn-success">Subscribe</a>
                        <?php else : ?>
                            <button class="btn btn-primary" disabled>View Details</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
